nohup python server.py &
